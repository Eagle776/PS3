var http = require('showtime/http');
var string = require('native/string');

function searchM3U(page, searchTerm, m3uUrl) {
  // Convertir el término de búsqueda a minúsculas
  searchTerm = searchTerm.toLowerCase();

  // Descargar la lista M3U desde la URL
  page.metadata.title = 'Buscando...';
  page.loading = true;
  var m3u = http.request(m3uUrl).toString().split('\n');
  var results = [];
  
  // Parsear la lista M3U
  for (var i = 0; i < m3u.length; i++) {
    if (m3u[i].startsWith('#EXTINF')) {
      var match = m3u[i].match(/#EXTINF:.*,(.*)/);
      if (match && match[1].toLowerCase() === searchTerm) {
        results.push({ title: match[1], url: m3u[i + 1] });
      }
    }
  }

  page.loading = false;
  page.metadata.title = 'Resultados de búsqueda';

  if (results.length === 0) {
    page.error('No se encontraron resultados para "' + searchTerm + '".');
    return;
  }

  // Mostrar hasta 100 resultados por página
  var resultIndex = 0;
  function showResults() {
    for (var i = resultIndex; i < Math.min(results.length, resultIndex + 100); i++) {
      page.appendItem('videoparams:' + results[i].url, 'video', {
        title: results[i].title,
      });
    }

    resultIndex += 100;

    if (resultIndex < results.length) {
      page.appendAction('navmore', 'Cargar más resultados', function() {
        showResults();
      });
    }
  }

  showResults();
}

exports.searchM3U = searchM3U;
